<?php
/*
Plugin Name: Clear Custom Post Meta
Plugin URI: http://www.rehatched.com
Description: This plugin is more designed for developers.  Will allow you to clear out custom post type meta with one click.
Version: 1.0
Author: Rehatched Media
Author URI: http://www.rehatched.com
License: GPL2
*/

/*  Copyright 2013  Rehatched Media  (email : hello@rehatched.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

function rehatched_admin_actions()
{
	add_options_page('Clear Custom Meta','Clear Custom Meta','manage_options','clear_custom_meta','clear_custom_meta');
}
add_action('admin_menu', 'rehatched_admin_actions');

function clear_custom_meta()
{
    if(!isset($_POST['clear-db']))
    {
	?>
        <h1><a href="http://www.wpcloudlayer.com">Premium Managed WordPress Hosting</a></h1>
    <form method="post">
        <fieldset>
            <label for="text">Clear Post Meta?</label>
            <input type="text" id="text" name="clear-db" placeholder="Type YES to clear">
        </fieldset>
        <fieldset>
            <input type="submit" id="submit" name="submit" value="Clear">
        </fieldset>
    </form>
   <?php
    }
    else
    {
        if($_POST['clear-db'] == 'YES')
        {
            global $wpdb;
            $wpdb->query("DELETE FROM 'wp_postmeta' WHERE meta_value=''");

            echo "Custom Post Meta Cleared!";
        }
        else
		{
            echo "Please enter YES in order to clear out your custom post meta";
        }
    }
}